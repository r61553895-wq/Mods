package com.example.automarket;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class AutoMarketClient implements ClientModInitializer {

    /** Команда продажи (без слэша). */
    static final String COMMAND = "sellmine";
    /** Слот кнопки в меню, если /sellmine открывает меню. -1 = клик не нужен. */
    static final int CONFIRM_SLOT = -1;

    /** Ресурс, который мод продаёт. Чтобы добавить новый, допишите строку в onInitializeClient. */
    public static class Resource {
        final String name;
        final Item item;
        boolean enabled;

        Resource(String name, Item item, boolean enabled) {
            this.name = name;
            this.item = item;
            this.enabled = enabled;
        }
    }

    public static final List<Resource> RESOURCES = new ArrayList<>();
    static boolean enabled = false; // главный переключатель

    private static final Random RNG = new Random();
    private static KeyBinding menuKey;
    private static int cooldown = 0;
    private static int checkTimer = 0;
    private static boolean waitingForMenu = false;
    private static int waitTicks = 0;
    private static int clickDelay = 0;

    @Override
    public void onInitializeClient() {
        RESOURCES.add(new Resource("Лазурит", Items.LAPIS_LAZULI, true));

        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.automarket.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.automarket"));

        ClientTickEvents.END_CLIENT_TICK.register(AutoMarketClient::tick);
    }

    private static boolean hasSellable(MinecraftClient mc) {
        PlayerInventory inv = mc.player.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack stack = inv.getStack(i);
            if (stack.isEmpty()) continue;
            for (Resource r : RESOURCES) {
                if (r.enabled && stack.isOf(r.item)) return true;
            }
        }
        return false;
    }

    private static void tick(MinecraftClient mc) {
        while (menuKey.wasPressed()) {
            mc.setScreen(new MarketScreen());
        }
        if (mc.player == null || mc.getNetworkHandler() == null) return;

        if (cooldown > 0) cooldown--;

        // Если команда открыла меню, кликаем по кнопке и закрываем
        if (waitingForMenu) {
            if (mc.currentScreen instanceof HandledScreen<?>) {
                if (++clickDelay >= 4 + RNG.nextInt(4)) {
                    mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId,
                            CONFIRM_SLOT, 0, SlotActionType.PICKUP, mc.player);
                    mc.player.closeHandledScreen();
                    waitingForMenu = false;
                    clickDelay = 0;
                }
            } else if (++waitTicks > 40) {
                waitingForMenu = false;
            }
            return;
        }

        if (!enabled || cooldown > 0 || mc.currentScreen != null) return;
        if (++checkTimer < 10) return; // проверяем инвентарь каждые 0,5 сек
        checkTimer = 0;

        if (!hasSellable(mc)) return;

        mc.getNetworkHandler().sendChatCommand(COMMAND);
        cooldown = 100 + RNG.nextInt(60); // 5-8 сек до следующей отправки

        if (CONFIRM_SLOT >= 0) {
            waitingForMenu = true;
            waitTicks = 0;
            clickDelay = 0;
        }
    }

    private static Text onOff(String name, boolean on) {
        return Text.literal(name + ": " + (on ? "§aВКЛ" : "§cВЫКЛ"));
    }

    /** Главное меню (правый Shift): переключатель и шестерёнка. */
    public static class MarketScreen extends Screen {
        public MarketScreen() {
            super(Text.literal("AutoMarket"));
        }

        @Override
        protected void init() {
            int y = height / 2 - 20;
            addDrawableChild(ButtonWidget.builder(onOff("Автопродажа /" + COMMAND, enabled), b -> {
                enabled = !enabled;
                cooldown = 0;
                b.setMessage(onOff("Автопродажа /" + COMMAND, enabled));
            }).dimensions(width / 2 - 100, y, 176, 20).build());

            addDrawableChild(ButtonWidget.builder(Text.literal("⚙"), b -> client.setScreen(new ResourceScreen(this)))
                    .dimensions(width / 2 + 80, y, 20, 20).build());

            addDrawableChild(ButtonWidget.builder(Text.literal("Закрыть"), b -> close())
                    .dimensions(width / 2 - 100, y + 32, 200, 20).build());
        }

        @Override
        public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
            super.render(ctx, mouseX, mouseY, delta);
            ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, height / 2 - 45, 0xFFFFFF);
        }
    }

    /** Выбор ресурсов для продажи. */
    public static class ResourceScreen extends Screen {
        private final Screen parent;

        public ResourceScreen(Screen parent) {
            super(Text.literal("Что продавать"));
            this.parent = parent;
        }

        @Override
        protected void init() {
            int y = height / 2 - 30;
            for (Resource r : RESOURCES) {
                addDrawableChild(ButtonWidget.builder(onOff(r.name, r.enabled), b -> {
                    r.enabled = !r.enabled;
                    b.setMessage(onOff(r.name, r.enabled));
                }).dimensions(width / 2 - 100, y, 200, 20).build());
                y += 24;
            }
            addDrawableChild(ButtonWidget.builder(Text.literal("Назад"), b -> close())
                    .dimensions(width / 2 - 100, y + 8, 200, 20).build());
        }

        @Override
        public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
            super.render(ctx, mouseX, mouseY, delta);
            ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, height / 2 - 55, 0xFFFFFF);
        }

        @Override
        public void close() {
            client.setScreen(parent);
        }
    }
}
