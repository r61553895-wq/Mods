package com.example.automarket;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket;
import net.minecraft.network.packet.s2c.play.OpenScreenS2CPacket;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Random;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class AutoMarketClient implements ClientModInitializer {

    /** Команда продажи (без слэша). */
    static final String COMMAND = "sellmine";
    /** Размер стака для режима "только стаками". */
    static final int STACK_SIZE = 64;
    /** Слова в названии предмета-кнопки, по которым мод сам находит кнопку продажи в меню. */
    static final String[] KEYWORDS = {"продать", "продат", "sell", "подтверд", "confirm", "принять", "accept"};

    // Цвета интерфейса (ARGB)
    static final int C_PANEL = 0xF0121520;
    static final int C_ACCENT = 0xFF3DDC97;
    static final int C_RED = 0xFFE5534B;
    static final int C_ROW = 0xFF1B1F2E;
    static final int C_ROW_HOVER = 0xFF262C42;
    static final int C_TEXT = 0xFFFFFFFF;
    static final int C_MUTED = 0xFF8E96AA;

    /** Ресурс для автопродажи. Чтобы добавить новый, допишите строку в onInitializeClient. */
    public static class Resource {
        final String id;
        final String name;
        final Item icon;
        final Item[] items;
        final String[] stems; // куски названия, по которым ищем пункт в меню сервера
        boolean enabled;

        Resource(String id, String name, boolean enabled, String[] stems, Item... items) {
            this.id = id;
            this.name = name;
            this.enabled = enabled;
            this.stems = stems;
            this.items = items;
            this.icon = items[0];
        }

        boolean matches(ItemStack stack) {
            for (Item i : items) {
                if (stack.isOf(i)) return true;
            }
            return false;
        }

        /** Подходит ли предмет в меню сервера: по типу предмета или по названию. */
        boolean matchesMenu(ItemStack stack) {
            if (matches(stack)) return true;
            String n = stack.getName().getString().toLowerCase(Locale.ROOT);
            for (String st : stems) {
                if (n.contains(st)) return true;
            }
            return false;
        }
    }

    public static final List<Resource> RESOURCES = new ArrayList<>();
    static boolean enabled = false;    // главный переключатель
    static boolean stackOnly = true;   // продавать только когда набрался стак
    static boolean hideMenu = true;    // не показывать меню сервера, можно ходить и копать
    static boolean debugMenu = false;   // печатать содержимое меню в чат
    static int confirmSlot = -1;       // слот кнопки в меню, -1 = искать по названию

    private static final Random RNG = new Random();
    private static KeyBinding menuKey;
    private static KeyBinding toggleKey;
    private static int cooldown = 0;
    private static int checkTimer = 0;
    private static int pendingSecond = -1;   // тиков до второй команды (-1 = не ждём)
    private static int expectTicks = 0;      // сколько ещё ждём открытия меню после второй команды
    private static boolean awaitingMenu = false;
    private static int menuTicks = -1;       // сколько тиков открыто меню (-1 = не обрабатываем)
    private static boolean queueBuilt = false;
    private static boolean clickedThisRound = false;
    private static boolean silentMenu = false;   // меню открыто "тихо", без экрана
    private static int actAt = 2;            // с какого тика меню ищем и жмём
    private static int closeAt = 6;          // на каком тике закрываем
    private static int nextClick = 0;        // на каком тике следующий клик
    private static final List<Integer> clickQueue = new ArrayList<>();

    @Override
    public void onInitializeClient() {
        RESOURCES.add(new Resource("lapis", "Лазурит", true, new String[]{"лазурит", "lapis"}, Items.LAPIS_LAZULI));
        RESOURCES.add(new Resource("diamond", "Алмазы", false, new String[]{"алмаз", "diamond"}, Items.DIAMOND));
        RESOURCES.add(new Resource("gold", "Золото", false, new String[]{"золот", "gold"}, Items.RAW_GOLD, Items.GOLD_INGOT));
        RESOURCES.add(new Resource("coal", "Уголь", false, new String[]{"уголь", "угл", "coal"}, Items.COAL));

        load();

        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.automarket.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.automarket"));
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.automarket.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, "category.automarket"));

        ClientTickEvents.END_CLIENT_TICK.register(AutoMarketClient::tick);
    }

    // ---------- Сохранение настроек ----------

    private static Path configPath() {
        return FabricLoader.getInstance().getConfigDir().resolve("automarket.properties");
    }

    static void load() {
        Path p = configPath();
        if (!Files.exists(p)) return;
        try (InputStream in = Files.newInputStream(p)) {
            Properties pr = new Properties();
            pr.load(in);
            enabled = Boolean.parseBoolean(pr.getProperty("enabled", "false"));
            stackOnly = Boolean.parseBoolean(pr.getProperty("stackOnly", "true"));
            hideMenu = Boolean.parseBoolean(pr.getProperty("hideMenu", "true"));
            debugMenu = Boolean.parseBoolean(pr.getProperty("debugMenu", "false"));
            confirmSlot = Integer.parseInt(pr.getProperty("confirmSlot", "-1").trim());
            for (Resource r : RESOURCES) {
                r.enabled = Boolean.parseBoolean(pr.getProperty("res." + r.id, String.valueOf(r.enabled)));
            }
        } catch (IOException | RuntimeException ignored) {
            // битый конфиг игнорируем, остаются значения по умолчанию
        }
    }

    static void save() {
        Properties pr = new Properties();
        pr.setProperty("enabled", String.valueOf(enabled));
        pr.setProperty("stackOnly", String.valueOf(stackOnly));
        pr.setProperty("hideMenu", String.valueOf(hideMenu));
        pr.setProperty("debugMenu", String.valueOf(debugMenu));
        pr.setProperty("confirmSlot", String.valueOf(confirmSlot));
        for (Resource r : RESOURCES) {
            pr.setProperty("res." + r.id, String.valueOf(r.enabled));
        }
        try (OutputStream out = Files.newOutputStream(configPath())) {
            pr.store(out, "AutoMarket");
        } catch (IOException | RuntimeException ignored) {
            // не удалось сохранить, не страшно
        }
    }

    // ---------- Логика ----------

    private static void chat(MinecraftClient mc, String msg) {
        if (mc.player != null) mc.player.sendMessage(Text.literal(msg), false);
    }

    /** Нужно ли сейчас продавать этот ресурс (включён, есть в инвентаре, набрался стак если нужно). */
    private static boolean qualifies(MinecraftClient mc, Resource r) {
        if (!r.enabled) return false;
        PlayerInventory inv = mc.player.getInventory();
        int total = 0;
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (!s.isEmpty() && r.matches(s)) total += s.getCount();
        }
        return total > 0 && (!stackOnly || total >= STACK_SIZE);
    }

    private static boolean shouldSell(MinecraftClient mc) {
        for (Resource r : RESOURCES) {
            if (qualifies(mc, r)) return true;
        }
        return false;
    }

    /** Слот в меню сервера, где лежит иконка этого ресурса (по ней нужно кликнуть). */
    private static int findResourceSlot(ScreenHandler h, Resource r) {
        int n = menuSlots(h);
        for (int i = 0; i < n; i++) {
            ItemStack s = h.slots.get(i).getStack();
            if (!s.isEmpty() && r.matchesMenu(s)) return i;
        }
        return -1;
    }

    /** Сколько слотов относится к самому меню (без инвентаря игрока, это последние 36). */
    private static int menuSlots(ScreenHandler h) {
        return Math.max(0, h.slots.size() - 36);
    }

    private static int findButton(ScreenHandler h) {
        int n = menuSlots(h);
        for (int i = 0; i < n; i++) {
            ItemStack s = h.slots.get(i).getStack();
            if (s.isEmpty()) continue;
            String name = s.getName().getString().toLowerCase(Locale.ROOT);
            for (String k : KEYWORDS) {
                if (name.contains(k)) return i;
            }
        }
        return -1;
    }

    private static void dumpMenu(MinecraftClient mc, ScreenHandler h) {
        String title = mc.currentScreen == null ? "?" : mc.currentScreen.getTitle().getString();
        chat(mc, "§e[AM] Меню: §f" + title + " §7(слотов меню: " + menuSlots(h) + ")");
        int n = menuSlots(h);
        for (int i = 0; i < n; i++) {
            ItemStack s = h.slots.get(i).getStack();
            if (s.isEmpty()) continue;
            chat(mc, "§7[AM] " + i + ": §f" + s.getName().getString()
                    + " §8(" + Registries.ITEM.getId(s.getItem()).getPath() + ")");
        }
    }

    /**
     * Вызывается из миксина, когда сервер хочет открыть меню.
     * Если мы его ждём, экран не открываем: просто подключаем контейнер к игроку,
     * и можно спокойно ходить и копать, пока идёт продажа.
     * Возвращает true, если стандартное открытие экрана нужно отменить.
     */
    public static boolean onServerOpenScreen(MinecraftClient mc, OpenScreenS2CPacket packet) {
        if (!hideMenu || !awaitingMenu || expectTicks <= 0 || menuTicks >= 0) return false;
        if (mc.player == null || mc.currentScreen != null) return false;
        ScreenHandlerType<?> type = packet.getScreenHandlerType();
        if (type == null) return false;
        try {
            ScreenHandler handler = type.create(packet.getSyncId(), mc.player.getInventory());
            mc.player.currentScreenHandler = handler;
            silentMenu = true;
            return true;
        } catch (RuntimeException e) {
            return false;
        }
    }

    private static void closeMenu(MinecraftClient mc) {
        if (silentMenu) {
            ScreenHandler h = mc.player.currentScreenHandler;
            if (h != mc.player.playerScreenHandler && mc.getNetworkHandler() != null) {
                mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(h.syncId));
            }
            mc.player.currentScreenHandler = mc.player.playerScreenHandler;
            silentMenu = false;
        } else {
            mc.player.closeHandledScreen();
        }
    }

    /** Обработка меню, которое открыла вторая команда: быстро кликаем по ресурсам и закрываем. */
    private static void handleMenu(MinecraftClient mc) {
        ScreenHandler h = mc.player.currentScreenHandler;
        menuTicks++;

        // Ждём, пока сервер пришлёт содержимое меню (обычно это 1-2 тика)
        if (!queueBuilt && menuTicks >= actAt) {
            boolean anyItem = false;
            int n = menuSlots(h);
            for (int i = 0; i < n; i++) {
                if (!h.slots.get(i).getStack().isEmpty()) {
                    anyItem = true;
                    break;
                }
            }
            if (anyItem || menuTicks >= 14) {
                if (debugMenu) dumpMenu(mc, h);
                clickQueue.clear();
                if (confirmSlot >= 0) {
                    clickQueue.add(confirmSlot);
                } else {
                    for (Resource r : RESOURCES) {
                        if (!qualifies(mc, r)) continue;
                        int slot = findResourceSlot(h, r);
                        if (slot >= 0) clickQueue.add(slot);
                        else if (debugMenu) chat(mc, "§c[AM] В меню нет пункта: " + r.name);
                    }
                    if (clickQueue.isEmpty()) {
                        int slot = findButton(h);
                        if (slot >= 0) clickQueue.add(slot);
                    }
                }
                if (clickQueue.isEmpty() && debugMenu) {
                    chat(mc, "§c[AM] Нечего нажимать. Можно выбрать слот вручную в настройках (+/-).");
                }
                queueBuilt = true;
                nextClick = menuTicks;
                closeAt = menuTicks + 1;
            }
        }

        if (queueBuilt && !clickQueue.isEmpty() && menuTicks >= nextClick) {
            int slot = clickQueue.remove(0);
            if (slot < h.slots.size() && mc.interactionManager != null) {
                mc.interactionManager.clickSlot(h.syncId, slot, 0, SlotActionType.PICKUP, mc.player);
                clickedThisRound = true;
                if (debugMenu) chat(mc, "§a[AM] Кликнул по слоту " + slot);
            }
            nextClick = menuTicks + 2 + RNG.nextInt(2);
            closeAt = nextClick + 1 + RNG.nextInt(2); // закрываем сразу после последнего клика
        }

        if ((queueBuilt && clickQueue.isEmpty() && menuTicks >= closeAt) || menuTicks > 60) {
            clickQueue.clear();
            closeMenu(mc);
            menuTicks = -1;
            expectTicks = 0;
            queueBuilt = false;
            cooldown = clickedThisRound ? 10 : 200; // если ничего не продали, делаем долгую паузу
            clickedThisRound = false;
        }
    }

    private static void resetState(MinecraftClient mc) {
        if (silentMenu && mc.player != null) closeMenu(mc);
        silentMenu = false;
        menuTicks = -1;
        expectTicks = 0;
        pendingSecond = -1;
        awaitingMenu = false;
        queueBuilt = false;
        clickedThisRound = false;
        clickQueue.clear();
    }

    private static void tick(MinecraftClient mc) {
        while (menuKey.wasPressed()) {
            mc.setScreen(new MainScreen());
        }
        if (mc.player == null || mc.getNetworkHandler() == null) {
            resetState(mc);
            return;
        }

        while (toggleKey.wasPressed()) {
            enabled = !enabled;
            cooldown = 0;
            resetState(mc);
            save();
            mc.player.sendMessage(Text.literal("AutoMarket: " + (enabled ? "§aВКЛ" : "§cВЫКЛ")), true);
        }

        if (cooldown > 0) cooldown--;
        if (expectTicks > 0) {
            expectTicks--;
            // меню так и не открылось: делаем долгую паузу, чтобы не спамить командами
            if (expectTicks == 0 && awaitingMenu && menuTicks < 0) {
                awaitingMenu = false;
                cooldown = Math.max(cooldown, 200);
            }
        }

        boolean containerOpen = mc.player.currentScreenHandler != mc.player.playerScreenHandler
                && (silentMenu || mc.currentScreen instanceof HandledScreen<?>);

        // Меню, которое открылось после второй команды
        if (containerOpen && (menuTicks >= 0 || expectTicks > 0)) {
            if (menuTicks < 0) {
                menuTicks = 0;
                awaitingMenu = false;
                queueBuilt = false;
                clickedThisRound = false;
                actAt = 2 + RNG.nextInt(2);
            }
            handleMenu(mc);
            return;
        }
        if (!containerOpen) menuTicks = -1;

        // Вторая команда: открывает меню продажи
        if (pendingSecond >= 0) {
            if (pendingSecond == 0) {
                mc.getNetworkHandler().sendChatCommand(COMMAND);
                expectTicks = 40; // 2 сек на открытие меню
                awaitingMenu = true;
            }
            pendingSecond--;
            return;
        }

        if (!enabled || cooldown > 0 || mc.currentScreen != null) return;
        if (++checkTimer < 4) return; // проверяем инвентарь 5 раз в секунду
        checkTimer = 0;

        if (!shouldSell(mc)) return;

        // Первая команда: начисляет монеты за добытые ресурсы
        mc.getNetworkHandler().sendChatCommand(COMMAND);
        pendingSecond = 5 + RNG.nextInt(3); // вторая команда через ~0,3 сек
        cooldown = 60;
    }

    // ---------- Интерфейс ----------

    /** Строка-переключатель с иконкой и "тумблером". */
    static class ToggleRow extends ClickableWidget {
        private final String label;
        private final ItemStack icon;
        private final Supplier<Boolean> state;
        private final Consumer<Boolean> setter;

        ToggleRow(int x, int y, int w, int h, String label, ItemStack icon,
                  Supplier<Boolean> state, Consumer<Boolean> setter) {
            super(x, y, w, h, Text.literal(label));
            this.label = label;
            this.icon = icon;
            this.state = state;
            this.setter = setter;
        }

        @Override
        protected void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
            int x = getX(), y = getY(), w = getWidth(), h = getHeight();
            boolean on = state.get();
            MinecraftClient mc = MinecraftClient.getInstance();

            ctx.fill(x, y, x + w, y + h, isHovered() ? C_ROW_HOVER : C_ROW);
            ctx.fill(x, y, x + 2, y + h, on ? C_ACCENT : C_RED);

            int tx = x + 9;
            if (icon != null) {
                ctx.drawItem(icon, x + 7, y + (h - 16) / 2);
                tx = x + 30;
            }
            ctx.drawTextWithShadow(mc.textRenderer, label, tx, y + (h - 8) / 2, C_TEXT);

            int pw = 30, ph = 14;
            int px = x + w - pw - 8, py = y + (h - ph) / 2;
            ctx.fill(px, py, px + pw, py + ph, on ? 0xFF1F5E45 : 0xFF4A2828);
            int kx = on ? px + pw - ph + 1 : px + 1;
            ctx.fill(kx, py + 1, kx + ph - 2, py + ph - 1, on ? C_ACCENT : C_RED);
        }

        @Override
        public void onClick(double mouseX, double mouseY) {
            setter.accept(!state.get());
        }

        @Override
        protected void appendClickableNarrations(NarrationMessageBuilder builder) {
            appendDefaultNarrations(builder);
        }
    }

    /** Плоская кнопка. */
    static class FlatButton extends ClickableWidget {
        private final Runnable action;

        FlatButton(int x, int y, int w, int h, String label, Runnable action) {
            super(x, y, w, h, Text.literal(label));
            this.action = action;
        }

        @Override
        protected void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
            int x = getX(), y = getY(), w = getWidth(), h = getHeight();
            MinecraftClient mc = MinecraftClient.getInstance();
            ctx.fill(x, y, x + w, y + h, isHovered() ? C_ROW_HOVER : C_ROW);
            ctx.fill(x, y + h - 1, x + w, y + h, isHovered() ? C_ACCENT : 0xFF343B55);
            ctx.drawCenteredTextWithShadow(mc.textRenderer, getMessage(), x + w / 2, y + (h - 8) / 2, C_TEXT);
        }

        @Override
        public void onClick(double mouseX, double mouseY) {
            action.run();
        }

        @Override
        protected void appendClickableNarrations(NarrationMessageBuilder builder) {
            appendDefaultNarrations(builder);
        }
    }

    /** Базовый экран: тёмная панель с акцентной полосой, заголовком и подзаголовком. */
    abstract static class PanelScreen extends Screen {
        final int pw;
        final int ph;
        final String subtitle;

        PanelScreen(String title, String subtitle, int pw, int ph) {
            super(Text.literal(title));
            this.subtitle = subtitle;
            this.pw = pw;
            this.ph = ph;
        }

        int panelX() {
            return (width - pw) / 2;
        }

        int panelY() {
            return (height - ph) / 2;
        }

        @Override
        public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
            super.renderBackground(ctx, mouseX, mouseY, delta);
            int x = panelX(), y = panelY();
            ctx.fill(x - 1, y - 1, x + pw + 1, y + ph + 1, 0xFF2A3148);
            ctx.fill(x, y, x + pw, y + ph, C_PANEL);
            ctx.fill(x, y, x + pw, y + 3, C_ACCENT);
            ctx.drawCenteredTextWithShadow(textRenderer, title.copy().formatted(Formatting.BOLD), width / 2, y + 11, C_TEXT);
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(subtitle), width / 2, y + 24, C_MUTED);
        }

        @Override
        public boolean shouldPause() {
            return false;
        }
    }

    /** Главное меню (правый Shift). */
    public static class MainScreen extends PanelScreen {
        public MainScreen() {
            super("AutoMarket", "Автопродажа через /" + COMMAND, 230, 138);
        }

        @Override
        protected void init() {
            int x = panelX() + 12, y = panelY(), w = pw - 24;
            addDrawableChild(new ToggleRow(x, y + 44, w, 26, "Автопродажа", null,
                    () -> enabled, v -> {
                        enabled = v;
                        cooldown = 0;
                        save();
                    }));
            addDrawableChild(new FlatButton(x, y + 80, w, 22, "⚙  Настройки",
                    () -> client.setScreen(new SettingsScreen(this))));
            addDrawableChild(new FlatButton(x, y + 106, w, 22, "Закрыть", this::close));
        }
    }

    /** Настройки: режим "только стаками", скрытое меню, диагностика, слот кнопки и выбор ресурсов. */
    public static class SettingsScreen extends PanelScreen {
        private final Screen parent;

        public SettingsScreen(Screen parent) {
            super("Настройки", "Что и как продавать", 230, 170 + RESOURCES.size() * 22);
            this.parent = parent;
        }

        @Override
        protected void init() {
            int x = panelX() + 12, y = panelY(), w = pw - 24;

            addDrawableChild(new ToggleRow(x, y + 36, w, 20, "Только стаками (от " + STACK_SIZE + ")", null,
                    () -> stackOnly, v -> {
                        stackOnly = v;
                        save();
                    }));
            addDrawableChild(new ToggleRow(x, y + 58, w, 20, "Скрыть меню продажи", null,
                    () -> hideMenu, v -> {
                        hideMenu = v;
                        save();
                    }));
            addDrawableChild(new ToggleRow(x, y + 80, w, 20, "Диагностика (чат)", null,
                    () -> debugMenu, v -> {
                        debugMenu = v;
                        save();
                    }));

            addDrawableChild(new FlatButton(x + w - 44, y + 102, 20, 20, "-", () -> {
                confirmSlot = Math.max(-1, confirmSlot - 1);
                save();
            }));
            addDrawableChild(new FlatButton(x + w - 20, y + 102, 20, 20, "+", () -> {
                confirmSlot = Math.min(53, confirmSlot + 1);
                save();
            }));

            int ry = y + 140;
            for (Resource r : RESOURCES) {
                addDrawableChild(new ToggleRow(x, ry, w, 20, r.name, new ItemStack(r.icon),
                        () -> r.enabled, v -> {
                            r.enabled = v;
                            save();
                        }));
                ry += 22;
            }
            addDrawableChild(new FlatButton(x, ry + 2, w, 20, "Назад", this::close));
        }

        @Override
        public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
            super.render(ctx, mouseX, mouseY, delta);
            int x = panelX() + 12, y = panelY(), w = pw - 24;

            // подпись слота (левее кнопок -/+)
            ctx.fill(x, y + 102, x + w - 48, y + 122, C_ROW);
            ctx.fill(x, y + 102, x + 2, y + 122, C_ACCENT);
            String slot = confirmSlot < 0 ? "авто" : String.valueOf(confirmSlot);
            ctx.drawTextWithShadow(textRenderer, "Слот кнопки: " + slot, x + 9, y + 108, C_TEXT);

            ctx.drawTextWithShadow(textRenderer, "Ресурсы", x + 2, y + 128, C_MUTED);
        }

        @Override
        public void close() {
            save();
            client.setScreen(parent);
        }
    }
}
