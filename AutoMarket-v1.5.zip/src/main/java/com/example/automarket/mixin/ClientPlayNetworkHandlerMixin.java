package com.example.automarket.mixin;

import com.example.automarket.AutoMarketClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.OpenScreenS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerMixin {

    @Inject(method = "onOpenScreen", at = @At("HEAD"), cancellable = true)
    private void automarket$silentOpen(OpenScreenS2CPacket packet, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        // пакет сначала приходит в сетевом потоке, действуем только в основном
        if (!mc.isOnThread()) return;
        if (AutoMarketClient.onServerOpenScreen(mc, packet)) {
            ci.cancel();
        }
    }
}
